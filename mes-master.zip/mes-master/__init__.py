# -*- coding: utf-8 -*-

__about__ = """
This project takes the account_project and adds profiles and notifications.
It is a foundation suitable for many sites that have user accounts with
profiles.
"""
