'''
from django.contrib import admin
from device.models import ToolMagazine
from device.models import Tool
from device.models import Device

admin.site.register(ToolMagazine)
admin.site.register(Tool)
admin.site.register(Device)
'''