from django.conf.urls.defaults import *

# URL patterns for django-workflows

urlpatterns = patterns('django-workflows.views',
  # Add url patterns here
)
