from django.conf.urls import patterns, include, url
