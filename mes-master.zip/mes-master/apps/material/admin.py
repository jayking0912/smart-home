'''
from django.contrib import admin
from material.models import Material 


admin.site.register(Material)
'''