__author__ = 'yeahren'
__all__ = ["IBotSignature"]
