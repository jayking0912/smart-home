#ibotcloud python sdk

See the fucking demo.py source !